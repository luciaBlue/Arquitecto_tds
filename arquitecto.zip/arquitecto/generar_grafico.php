<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfico de Gastos de Obras</title>
    <link rel="stylesheet" href="css/mystyle1.css">

    <script src="https://code.highcharts.com/highcharts.js"></script>

    <style> 
        body {
            background: #555;
        }
    </style>
</head>
<body>
<div id="grafico"></div>

<?php
session_start();
require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    $id_usuario = $_SESSION["id_usuario"];

    // Consulta para obtener los datos de las obras y los materiales asociados
    $sql = "SELECT obras.id_obras, obras.nombre_obra, obras.estado, materiales.ruta_archivo AS Materiales,
                   planos.ruta_archivo AS Planos, gastos.valor AS Gastos,
                   avances.ruta_archivo AS Avances
            FROM obras
            LEFT JOIN materiales ON obras.id_obras = materiales.id_obras
            LEFT JOIN planos ON obras.id_obras = planos.id_obras
            LEFT JOIN gastos ON obras.id_obras = gastos.id_obras
            LEFT JOIN avances ON obras.id_obras = avances.id_obras
            WHERE obras.id_registro = $id_usuario
            AND obras.eliminar = 'pendiente'";
    $result = $mysqli->query($sql);

    // Arreglo para almacenar los datos de las obras
    $obrasData = [];

    while ($row = $result->fetch_assoc()) {
        // Agrega los datos de la obra actual al arreglo
        $obrasData[] = [
            'nombre' => $row["nombre_obra"],
            'gastos' => $row["Gastos"],
            'estado' => $row["estado"] 
        ];
    }
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Configura el gráfico de Highcharts
    Highcharts.chart('grafico', {
        chart: {
            type: 'column',
            backgroundColor: '#f5f5f5',
            borderRadius: 5
        },
        title: {
            text: 'Gastos de todas las obras',
            style: {
                color: '#333',
                fontSize: '24px'
            }
        },
        xAxis: {
            categories: <?php echo json_encode(array_column($obrasData, 'nombre')); ?>
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Gastos',
                style: {
                    color: '#333',
                    fontWeight: 'bold'
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: 'Gastos',
            data: <?php echo json_encode(array_column($obrasData, 'gastos'), JSON_NUMERIC_CHECK); ?>
        }],
        plotOptions: {
            column: {
                colorByPoint: true
            }
        },
        credits: {
            enabled: false
        }
    });
});
</script>
<?php

    $result->free();
    $mysqli->close();
} else {
    echo "SESION CADUCADA.";
}
?>
</body>
</html>
