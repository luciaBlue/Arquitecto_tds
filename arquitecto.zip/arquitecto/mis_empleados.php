<?php
session_start();
require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    $id_usuario = $_SESSION["id_usuario"];

    $sql = "SELECT
            o.id_obras,
            o.nombre_obra,
            i.id_informe,
            i.titulo,
            i.ruta_archivo AS informe,
            i.horas,
            CONCAT(r.nombres, ' ', r.apellidos) AS nombre_empleado
        FROM obras o
        LEFT JOIN asignacion_empleados_obras a ON o.id_obras = a.id_obras
        LEFT JOIN informes_empleados i ON o.id_obras = i.id_obras
        LEFT JOIN registro r ON a.id_empleado = r.id_registro
        WHERE i.eliminar = 'pendiente'
        ORDER BY o.id_obras, i.id_informe";

    $result = $mysqli->query($sql);
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Empleado</title>
        <link rel="stylesheet" href="css/mystyle1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="icon-bar">
            <a href="pagArquitecto.php"><i class="fa fa-home"></i></a>
            <a href="obras.php"><i class="fa-solid fa-calendar-days"></i></a>
            <a href="materiales.php"><i class="fa-solid fa-trowel-bricks"></i></a>
            <a href="planos.php"><i class="fa-solid fa-paste"></i></a>
            <a href="gastos.php"><i class="fa-solid fa-coins"></i></a>
            <a href="avances.php"><i class="fa-solid fa-check"></i></a>
            <a href="mis_empleados.php"><i class="fa-solid fa-table-cells"></i></a>
            <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>
        </div>

        <div class="tabla-listado">
            <h2>Obras</h2>
            <table>
                <tr>
                    <th>Nombre Obra</th> 
                    <th>Nombre de Empleado</th>
                    <th>Título del Informe</th>
                    <th>Horas Trabajadas</th>
                    <th>Informe</th>
                </tr>

                <?php $current_obra = null; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row["nombre_obra"]; ?></td>

                        <td><?php echo $row["nombre_empleado"]; ?></td>

                        <td><?php echo $row["titulo"]; ?></td>

                        <td><?php echo $row["horas"]; ?></td>

                        <td>
                            <?php if (!empty($row["informe"])): ?>
                                <a href="<?php echo $row["informe"]; ?>" download="<?php echo basename($row["informe"]); ?>">
                                    <?php echo basename($row["informe"]); ?>
                                </a>
                            <?php else: ?>
                                No hay informe disponible
                            <?php endif; ?>
                        </td>

                    </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </body>
    </html>

    <?php
    $result->free();
    $mysqli->close();
} else {
    echo "SESION CADUCADA.";
}
?>
