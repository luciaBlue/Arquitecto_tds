<?php
session_start();
require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    $id_usuario = $_SESSION["id_usuario"];

    $sql = "SELECT
                o.id_obras,
                o.nombre_obra,
                i.id_informe,
                i.titulo,
                i.ruta_archivo AS informe,
                i.horas
            FROM obras o
            LEFT JOIN asignacion_empleados_obras a ON o.id_obras = a.id_obras
            LEFT JOIN informes_empleados i ON o.id_obras = i.id_obras
            WHERE a.id_empleado = $id_usuario AND i.eliminar = 'pendiente'
            ORDER BY o.id_obras, i.id_informe";

    $result = $mysqli->query($sql);
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Empleado</title>
        <link rel="stylesheet" href="css/mystyle1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="icon-bar">
            <a href="pagEmpleado.php"><i class="fa fa-home"></i></a>
            <a href="informes_empleados.php"><i class="fa-solid fa-file-circle-plus"></i></a>
            <a href="tabla_empleado.php"><i class="fa-solid fa-table-cells"></i></a>
            <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>
        </div>

        <div class="tabla-listado">
            <h2>Informes</h2>
            <hr>
            <table>
                <tr>
                    <th>Nombre Obra</th> 
                    <th>Titulo del Informe</th>
                    <th>Horas Trabajadas</th>
                    <th>Informe</th>
                    <th>Actualizar</th>
                    <th>Eliminar</th>
                    <th>Generar</th>
                </tr>

                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row["nombre_obra"]; ?></td>

                        <td><?php echo $row["titulo"]; ?></td>

                        <td><?php echo $row["horas"]; ?></td>

                        <td>
                            <?php if (!empty($row["informe"])): ?>
                                <a href="<?php echo $row["informe"]; ?>" download="<?php echo basename($row["informe"]); ?>">
                                    <?php echo basename($row["informe"]); ?>
                                </a>
                            <?php else: ?>
                                No hay informe disponible
                            <?php endif; ?>
                        </td>

                        <td>
                            <a href="editar_empleado.php?id_informe=<?php echo $row["id_informe"]; ?>"><img src="./images/icons8-Edit-32.png" alt="Editar"></a>
                        </td>

                        <td>
                            <a href="eliminar_empleado.php?id_informe=<?php echo $row["id_informe"]; ?>"><img src="./images/icons8-Trash-32.png" alt="Eliminar"></a>
                        </td>

                        <td>
                             <?php echo "<a href='pdf.php?id=" . $row['id_informe'] . "' download><i class='fa-solid fa-file-pdf'></i></a>" ?>
                        </td>

                    </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </body>
    </html>

    <?php
    $result->free();
    $mysqli->close();
} else {
    echo "SESION CADUCADA.";
}
?>
