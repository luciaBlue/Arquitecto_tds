<?php
session_start();
require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    $id_usuario = $_SESSION["id_usuario"];

    $sql = "SELECT obras.id_obras, obras.nombre_obra, obras.estado, 
               GROUP_CONCAT(DISTINCT materiales.ruta_archivo) AS Materiales,
               GROUP_CONCAT(DISTINCT planos.ruta_archivo) AS Planos, 
               SUM(gastos.valor) AS Gastos,
               GROUP_CONCAT(DISTINCT avances.ruta_archivo) AS Avances
        FROM obras
        LEFT JOIN materiales ON obras.id_obras = materiales.id_obras
        LEFT JOIN planos ON obras.id_obras = planos.id_obras
        LEFT JOIN gastos ON obras.id_obras = gastos.id_obras
        LEFT JOIN avances ON obras.id_obras = avances.id_obras
        LEFT JOIN asignacion_empleados_obras ON obras.id_obras = asignacion_empleados_obras.id_obras
        WHERE asignacion_empleados_obras.id_empleado = $id_usuario
        AND obras.eliminar = 'pendiente'
        GROUP BY obras.id_obras";


    $result = $mysqli->query($sql);

    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Empleado</title>
        <link rel="stylesheet" href="css/mystyle1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <div class="icon-bar">
        <a href="pagEmpleado.php"><i class="fa fa-home"></i></a>
        <a href="informes_empleados.php"><i class="fa-solid fa-file-circle-plus"></i></a>
        <a href="tabla_empleado.php"><i class="fa-solid fa-table-cells"></i></a>
        <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>

    <div class="tabla-listado">
        <h2>Obras</h2>
        <?php
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr>
                    <th>Nombre Obra</th>
                    <th>Estado</th>
                    <th>Materiales</th>
                    <th>Planos</th>
                    <th>Gastos</th>
                    <th>Avances</th>
                  </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["nombre_obra"] . "</td>";
                echo "<td>" . $row["estado"] . "</td>";
                echo "<td><a href='" . $row["Materiales"] . "' download>" . basename($row["Materiales"]) . "</a></td>";
                echo "<td><a href='" . $row["Planos"] . "' download>" . basename($row["Planos"]) . "</a></td>"; 
                echo "<td>" . $row["Gastos"] . " $" ."</td>"; 
                echo "<td><a href='" . $row["Avances"] . "' download>" . basename($row["Avances"]) . "</a></td>";  
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No hay obras asignadas.</p>";
        }
        ?>
    </div>
         
    </body>
    </html>
    <?php

    $result->free();
    $mysqli->close();
} else {
    echo "SESION CADUCADA.";
}
?>
