<?php
include("config.php");
session_start(); 

if (!isset($_SESSION["id_usuario"])) {
    echo "SESION CADUCADA.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gastos</title>
    <link rel="stylesheet" href="css/mystyle1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="icon-bar">
        <a href="pagArquitecto.php"><i class="fa fa-home"></i></a>
        <a href="obras.php"><i class="fa-solid fa-calendar-days"></i></a>
        <a href="materiales.php"><i class="fa-solid fa-trowel-bricks"></i></a>
        <a href="planos.php"><i class="fa-solid fa-paste"></i></a>
        <a href="gastos.php"><i class="fa-solid fa-coins"></i></a>
        <a href="avances.php"><i class="fa-solid fa-check"></i></a>
        <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>


    </div>

    <div class="formulario-obras">
        <h2 class="texto-secundario">Registrar Nuevo Gasto</h2>
        <form action="procesar_gasto.php" method="POST">
            <label for="gasto">Valor del Gasto:</label><br>
            <input type="number" id="gasto" name="gasto" required><br>

            <label for="descripcion_gasto">Descripción del Gasto:</label><br>
            <input type="text" id="descripcion_gasto" name="descripcion_gasto" required><br>

            <label for="fecha_gasto">Fecha del Gasto:</label><br>
            <input type="date" id="fecha_gasto" name="fecha_gasto" required><br>

            <label for="id_obra">Seleccionar Obra:</label><br>
            <select id="id_obra" name="id_obra" required>
            <?php
                    $query = "SELECT id_obras, nombre_obra FROM obras WHERE eliminar = 'pendiente'";
                    $result = $mysqli->query($query);
                    if (!$result) {
                        die('Error en la consulta SQL: ' . $mysqli->error);
                    }
                    while($row = $result->fetch_assoc()) {
                        echo "<option value=\"{$row['id_obras']}\">{$row['nombre_obra']}</option>";
                    }

                    $result->free();
                ?>
            </select><br>

            <div class="boton">
                <button type="submit">Agregar Gasto</button>
            </div>
        </form>
    </div>


    
</body>
</html>