<?php
include("config.php");
session_start(); 

if (!isset($_SESSION["id_usuario"])) {
    echo "SESION CADUCADA.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planos</title>
    <link rel="stylesheet" href="css/mystyle1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="icon-bar">
        <a href="pagArquitecto.php"><i class="fa fa-home"></i></a>
        <a href="obras.php"><i class="fa-solid fa-calendar-days"></i></a>
        <a href="materiales.php"><i class="fa-solid fa-trowel-bricks"></i></a>
        <a href="planos.php"><i class="fa-solid fa-paste"></i></a>
        <a href="gastos.php"><i class="fa-solid fa-coins"></i></a>
        <a href="avances.php"><i class="fa-solid fa-check"></i></a>
        <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>


    </div>
    

    <div class="formulario-obras">
        <h2 class="texto-secundario">Registro de Planos</h2>
        <form action="procesar_planos.php" method="POST" enctype="multipart/form-data">
            <label for="titulo">Título del Plano:</label><br>
            <input type="text" id="titulo" name="titulo" required><br><br>

            <label for="archivo">Archivo del Plano:</label><br>
            <input type="file" id="archivo" name="archivo" accept=".pdf,.jpg,.png" required><br><br>

            <label for="id_obras">Obra Asociada:</label><br>
            <select id="id_obras" name="id_obras" required>
                <?php
                    $query = "SELECT id_obras, nombre_obra FROM obras WHERE eliminar = 'pendiente'";
                    $result = $mysqli->query($query);
                    if (!$result) {
                        die('Error en la consulta SQL: ' . $mysqli->error);
                    }
                    while($row = $result->fetch_assoc()) {
                        echo "<option value=\"{$row['id_obras']}\">{$row['nombre_obra']}</option>";
                    }

                    $result->free();
                    $mysqli->close();
                ?>
            </select><br><br>

            <div class="boton">
                <button type="submit">Guardar</button>
            </div>
        </form>
    </div>

</body>
</html>