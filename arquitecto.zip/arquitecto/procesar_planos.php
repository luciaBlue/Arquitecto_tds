<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_obras = intval($_POST["id_obras"]); 
    $titulo = htmlspecialchars(trim($_POST["titulo"]));

    if (empty($titulo) || empty($id_obras)) {
        header("Location: planos.php?error=empty_fields");
        exit();
    }

    if ($_FILES["archivo"]["error"] == UPLOAD_ERR_OK) {
        $nombre_temporal = $_FILES["archivo"]["tmp_name"];
        $nombre_archivo = $_FILES["archivo"]["name"];
        $ruta_destino = "docs/" . $nombre_archivo;

        if (!move_uploaded_file($nombre_temporal, $ruta_destino)) {
            die('Error al mover el archivo cargado.');
        }
    } else {
        die('Error al cargar el archivo.');
    }

    // Verificar si ya existe un registro de planos para la obra seleccionada
    $stmt_check = $mysqli->prepare("SELECT id_planos FROM Planos WHERE id_obras = ?");
    $stmt_check->bind_param("i", $id_obras);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        // Ya existe un registro de planos para esta obra, actualizar el registro existente
        $stmt_update = $mysqli->prepare("UPDATE Planos SET titulo = ?, ruta_archivo = ? WHERE id_obras = ?");
        $stmt_update->bind_param("sss", $titulo, $ruta_destino, $id_obras);
        $stmt_update->execute();
        $stmt_update->close();
    } else {
        // No existe un registro de planos para esta obra, insertar un nuevo registro
        $stmt_insert = $mysqli->prepare("INSERT INTO Planos (id_obras, titulo, ruta_archivo) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("iss", $id_obras, $titulo, $ruta_destino);
        $stmt_insert->execute();
        $stmt_insert->close();
    }

    $stmt_check->close();

    header("Location: planos.php?success=true");
    exit();
} else {
    header("Location: planos.php");
    exit();
}

?>
