<?php
session_start();
require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    $id_usuario = $_SESSION["id_usuario"];

    // Consulta para obtener los datos de las obras y los materiales asociados
    $sql = "SELECT obras.id_obras, obras.nombre_obra, obras.estado, materiales.ruta_archivo AS Materiales,
                   planos.ruta_archivo AS Planos, gastos.valor AS Gastos,
                   avances.ruta_archivo AS Avances
            FROM obras
            LEFT JOIN materiales ON obras.id_obras = materiales.id_obras
            LEFT JOIN planos ON obras.id_obras = planos.id_obras
            LEFT JOIN gastos ON obras.id_obras = gastos.id_obras
            LEFT JOIN avances ON obras.id_obras = avances.id_obras
            WHERE obras.id_registro = $id_usuario
            AND obras.eliminar = 'pendiente'";
    $result = $mysqli->query($sql);

    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Arquitecto</title>
        <link rel="stylesheet" href="css/mystyle1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <div class="icon-bar">
        <a href="pagArquitecto.php"><i class="fa fa-home"></i></a>
        <a href="obras.php"><i class="fa-solid fa-calendar-days"></i></a>
        <a href="materiales.php"><i class="fa-solid fa-trowel-bricks"></i></a>
        <a href="planos.php"><i class="fa-solid fa-paste"></i></a>
        <a href="gastos.php"><i class="fa-solid fa-coins"></i></a>
        <a href="avances.php"><i class="fa-solid fa-check"></i></a>
        <a href="mis_empleados.php"><i class="fa-solid fa-table-cells"></i></a>
        <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>
</div>

<div class="tabla-listado">
    <div class="grafico">
        <h2>Obras</h2>

        <a href="generar_grafico.php" target="_blank"><i class="fa fa-bar-chart"></i> Visualizar Gráfico</a>
    </div>
    <hr>
        <?php
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr>
                    <th>Nombre Obra</th>
                    <th>Estado</th>
                    <th>Materiales</th>
                    <th>Planos</th>
                    <th>Gastos</th>
                    <th>Avances</th>
                    <th>Actualizar</th>
		            <th>Eliminar</th>
		            <th>Generar</th>
                  </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["nombre_obra"] . "</td>";
                echo "<td>" . $row["estado"] . "</td>";
                echo "<td><a href='" . $row["Materiales"] . "' download>" . basename($row["Materiales"]) . "</a></td>";
                echo "<td><a href='" . $row["Planos"] . "' download>" . basename($row["Planos"]) . "</a></td>"; 
                echo "<td>" . $row["Gastos"] . " $" ."</td>"; 
                echo "<td><a href='" . $row["Avances"] . "' download>" . basename($row["Avances"]) . "</a></td>";  
                echo "<td><a href='editar_obra.php?id=" . $row['id_obras'] . "'><img src='./images/icons8-Edit-32.png' alt='Edit'></a></td>";
                echo "<td><a href='eliminar.php?id=" . $row['id_obras'] . "'><img src='./images/icons8-Trash-32.png' alt='Delete'></a></td>";
                echo "<td><a href='generar_pdf.php?id=" . $row['id_obras'] . "'><i class='fa-solid fa-file-pdf'></i></a></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No hay obras registradas.</p>";
        }
        ?>
    </div>
    <div class="botonGenerar">

        <form class="generalPdf" action="generar_pdf_general.php" method="POST">
           <button type="submit">Generar PDF's general de Obras</button>
        </form>
    </div>
    </body>
    </html>
    <?php

    $result->free();
    $mysqli->close();
} else {
    echo "SESION CADUCADA.";
}
?>
