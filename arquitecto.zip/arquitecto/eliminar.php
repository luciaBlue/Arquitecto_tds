<?php
session_start();

require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    if (isset($_GET["id"])) {
        $id_obra = $_GET["id"];

        // Obtener los IDs de los empleados asignados a la obra que se está eliminando
        $sql_empleados_asignados = "SELECT id_empleado FROM asignacion_empleados_obras WHERE id_obras = $id_obra";
        $result_empleados_asignados = $mysqli->query($sql_empleados_asignados);

        if ($result_empleados_asignados->num_rows > 0) {
            while ($row = $result_empleados_asignados->fetch_assoc()) {
                $id_empleado = $row["id_empleado"];

                // Actualizar el estado en la tabla registro
                $sql_update_registro = "UPDATE registro SET estado = 'sin' WHERE id_registro = $id_empleado";
                $result_update_registro = $mysqli->query($sql_update_registro);
            }
        }

        // Actualizar el estado en la tabla obras
        $sql_update_obras = "UPDATE obras SET eliminar = 'eliminado' WHERE id_obras = $id_obra";
        $result_update_obras = $mysqli->query($sql_update_obras);

        // Actualizar el estado en las demás tablas relacionadas (materiales, planos, gastos, avances)
        $sql_update_materiales = "UPDATE materiales SET eliminar = 'eliminado' WHERE id_obras = $id_obra";
        $result_update_materiales = $mysqli->query($sql_update_materiales);

        $sql_update_planos = "UPDATE planos SET eliminar = 'eliminado' WHERE id_obras = $id_obra";
        $result_update_planos = $mysqli->query($sql_update_planos);

        $sql_update_gastos = "UPDATE gastos SET eliminar = 'eliminado' WHERE id_obras = $id_obra";
        $result_update_gastos = $mysqli->query($sql_update_gastos);

        $sql_update_avances = "UPDATE avances SET eliminar = 'eliminado' WHERE id_obras = $id_obra";
        $result_update_avances = $mysqli->query($sql_update_avances);

        if ($result_update_obras && $result_update_registro && $result_update_materiales && $result_update_planos && $result_update_gastos && $result_update_avances) {
            header("Location: pagArquitecto.php?success=true");
            exit();
        } else {
            header("Location: pagArquitecto.php");
            exit();
        }
    } else {
        echo "<script>alert('ID de obra no válido');</script>";
        echo "<script>window.location.href = 'tu_pagina.php';</script>";
    }
} else {
    echo "<script>alert('ID de usuario no válido');</script>";
    echo "<script>window.location.href = 'tu_pagina.php';</script>";
}

$mysqli->close();
?>
