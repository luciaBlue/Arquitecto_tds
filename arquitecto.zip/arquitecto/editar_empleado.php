<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

$id_informe = isset($_GET['id_informe']) ? $_GET['id_informe'] : null;

if ($id_informe !== null) {
    // Obtener los datos del informe a través de su ID
    $stmt = $mysqli->prepare("SELECT titulo, ruta_archivo, horas FROM informes_empleados WHERE id_informe = ?");
    $stmt->bind_param("i", $id_informe);
    $stmt->execute();
    $stmt->bind_result($titulo, $ruta_archivo, $horas);
    $stmt->fetch();
    $stmt->close();
} else {
    echo "ID del informe no proporcionado o inválido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Informe</title>
    <link rel="stylesheet" href="css/mystyle1.css">
</head>
<body>
    
    <div class="formulario-obras">
        <h2 class="texto-secundario">Editar Informe</h2>

        <form action="procesar_editar_empleado.php" method="POST" enctype="multipart/form-data">

            <input type="hidden" name="id_informe" value="<?php echo $id_informe; ?>">

            <label for="titulo">Título del Informe:</label><br>
            <input type="text" id="titulo" name="titulo" required value="<?php echo $titulo; ?>"><br>

            <label for="archivo">Cambiar Archivo:</label><br>
            <input type="file" id="archivo" name="archivo"><br>
            <!-- Aquí puedes mostrar el nombre del archivo actual si es que existe -->

            <label for="horas">Horas Trabajadas:</label><br>
            <input type="time" id="horas" name="horas" value="<?php echo $horas; ?>"><br>

            <div class="boton">
                <button type="submit">Guardar Cambios</button>
            </div>
        </form>
    </div>
</body>
</html>
