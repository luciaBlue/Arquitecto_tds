<?php
require 'config.php';

if (isset($_GET['id'])) {
    $id_obra = $_GET['id'];
    
    $sql = "DELETE FROM obras WHERE id_obras = $id_obra";
    if ($mysqli->query($sql) === TRUE) {
        header("Location: pagArquitecto.php");
        exit;
    } else {
        echo "Error al eliminar la obra: " . $mysqli->error;
    }
} else {
    echo "ID de obra no especificado.";
}
?>
