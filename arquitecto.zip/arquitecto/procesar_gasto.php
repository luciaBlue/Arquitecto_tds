<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gasto = $_POST["gasto"];
    $descripcion_gasto = $_POST["descripcion_gasto"];
    $fecha_gasto = $_POST["fecha_gasto"];
    $id_obra = $_POST["id_obra"];

    // aqui verificar si ya existe un gasto para esta obra
    $check_query = "SELECT id_gastos FROM Gastos WHERE id_obras = $id_obra";
    $check_result = $mysqli->query($check_query);

    if ($check_result && $check_result->num_rows > 0) {
        // Si ya existe un gasto para esta obra, actualizar el registro
        $update_query = "UPDATE Gastos SET valor = '$gasto', descripcion_gasto = '$descripcion_gasto', fecha_gasto = '$fecha_gasto' WHERE id_obras = $id_obra";
        if ($mysqli->query($update_query) === TRUE) {
            header("Location: gastos.php?success=true");
            exit;
        } else {
            echo "Error al actualizar el gasto: " . $mysqli->error;
        }
    } else {
        // Si no existe un gasto para esta obra, insertar un nuevo registro
        $insert_query = "INSERT INTO Gastos (id_obras, valor, descripcion_gasto, fecha_gasto) 
                         VALUES ('$id_obra', $gasto , '$descripcion_gasto', '$fecha_gasto')";
        if ($mysqli->query($insert_query) === TRUE) {
            header("Location: gastos.php?success=true");
            exit;
        } else {
            echo "Error al agregar el gasto: " . $mysqli->error;
        }
    }
}
?>
